package com.kelf.jfsd;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="client")
public class Project {
	@Id
	public int id;
	public String projectName;
	public String duration;
	public long budget;
	public Project(int id, String projectName, String duration, long budget) {
        this.id = id;
        this.projectName = projectName;
        this.duration = duration;
        this.budget = budget;
    }
	public long getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public long getBudget() {
		return budget;
	}
	public void setBudget(long budget) {
		this.budget = budget;
	}
	@Override
	public String toString() {
		return "Project [id=" + id + ", projectName=" + projectName + ", duration=" + duration + ", budget=" + budget
				+ "]";
	}
	
}
