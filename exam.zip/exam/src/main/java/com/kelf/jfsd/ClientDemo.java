package com.kelf.jfsd;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;

public class ClientDemo {
    public static void main(String[] args) {
        // Configure Hibernate
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        // Insert records
        Transaction transaction = session.beginTransaction();

        Project p1 = new Project(1, "Project A", "12 months", 100000);
        Project p2 = new Project(2, "Project B", "6 months", 75000);
        Project p3 = new Project(3, "Project C", "18 months", 150000);

        session.save(p1);
        session.save(p2);
        session.save(p3);

        transaction.commit();

        // Perform aggregate functions
        session.beginTransaction();

        Criteria criteriaCount = session.createCriteria(Project.class);
        criteriaCount.setProjection(Projections.rowCount());
        System.out.println("Total Projects: " + criteriaCount.uniqueResult());

        Criteria criteriaMax = session.createCriteria(Project.class);
        criteriaMax.setProjection(Projections.max("budget"));
        System.out.println("Max Budget: " + criteriaMax.uniqueResult());

        Criteria criteriaMin = session.createCriteria(Project.class);
        criteriaMin.setProjection(Projections.min("budget"));
        System.out.println("Min Budget: " + criteriaMin.uniqueResult());

        Criteria criteriaSum = session.createCriteria(Project.class);
        criteriaSum.setProjection(Projections.sum("budget"));
        System.out.println("Sum of Budgets: " + criteriaSum.uniqueResult());

        Criteria criteriaAvg = session.createCriteria(Project.class);
        criteriaAvg.setProjection(Projections.avg("budget"));
        System.out.println("Average Budget: " + criteriaAvg.uniqueResult());

        session.getTransaction().commit();

        // Close session and factory
        session.close();
        sessionFactory.close();
    }
}
